import React from 'react';
import { createRoot } from 'react-dom/client';
import { Github, Linkedin, Mail, ArrowUpRight, Code2, BrainCircuit, GraduationCap, Trophy, ExternalLink, Menu } from 'lucide-react';
import './style.css';

const skills = [
  { name: 'Python', level: 'Basics', icon: 'Py' },
  { name: 'Java', level: 'Programming', icon: 'Ja' },
  { name: 'HTML', level: 'Web basics', icon: '5' },
  { name: 'Problem Solving', level: 'Core strength', icon: '✳' },
  { name: 'Communication', level: 'Teamwork', icon: '↗' },
  { name: 'Quick Learner', level: 'Growth mindset', icon: '＋' },
];

function App() {
  return <div className="site-shell">
    <header className="topbar">
      <a className="brand" href="#home"><span className="brand-mark">VS</span><span>Veeranna<span className="brand-dot">.</span></span></a>
      <nav><a href="#about">About</a><a href="#skills">Skills</a><a href="#projects">Projects</a><a href="#education">Education</a></nav>
      <a className="nav-cta" href="mailto:veerannaswamy@example.com">Let's connect <ArrowUpRight size={15}/></a>
    </header>

    <main>
      <section className="hero section-wrap" id="home">
        <div className="hero-copy">
          <div className="availability"><span className="pulse"/> OPEN TO INTERNSHIP OPPORTUNITIES</div>
          <p className="eyebrow">HELLO, I'M</p>
          <h1>P. Veeranna<br/><span>Swamy.</span></h1>
          <h2>Aspiring Software Developer <span className="slash">/</span> AI &amp; ML Student</h2>
          <p className="hero-desc">I’m a B.Tech CSE (AI &amp; ML) student who enjoys turning ideas into practical digital solutions. I’m building my skills in programming, web fundamentals, and problem solving, one project at a time.</p>
          <div className="hero-actions"><a className="button primary" href="#projects">Explore my work <ArrowUpRight size={17}/></a><a className="button secondary" href="mailto:veerannaswamy@example.com"><Mail size={16}/> Contact me</a></div>
          <div className="social-row"><a href="https://www.linkedin.com/in/PADAMSETTIVEERANNASWAMY36" target="_blank" rel="noreferrer"><Linkedin size={17}/> LinkedIn <ExternalLink size={12}/></a><a href="https://github.com/swamyveeranna" target="_blank" rel="noreferrer"><Github size={17}/> GitHub <ExternalLink size={12}/></a></div>
        </div>
        <div className="hero-art" aria-label="Developer introduction graphic">
          <div className="orbit orbit-one"/><div className="orbit orbit-two"/>
          <div className="code-window"><div className="window-top"><div className="window-dots"><i/><i/><i/></div><span>developer.js</span><span className="window-menu">•••</span></div><div className="code-lines"><p><span className="ln">01</span><span className="pink">const</span> developer = {'{'}</p><p><span className="ln">02</span>&nbsp; name: <span className="green">'Veeranna Swamy'</span>,</p><p><span className="ln">03</span>&nbsp; field: <span className="green">'AI &amp; ML'</span>,</p><p><span className="ln">04</span>&nbsp; learning: [</p><p><span className="ln">05</span>&nbsp;&nbsp; <span className="yellow">'Python'</span>, <span className="yellow">'Java'</span>,</p><p><span className="ln">06</span>&nbsp;&nbsp; <span className="yellow">'Web Development'</span></p><p><span className="ln">07</span>&nbsp; ],</p><p><span className="ln">08</span>&nbsp; mindset: <span className="green">'Keep building'</span></p><p><span className="ln">09</span>{'}'};</p><p><span className="ln">10</span><span className="muted-code">// learn · build · improve</span></p></div></div>
          <div className="float-card float-python"><span className="mini-icon">Py</span><div><b>Python</b><small>Core skill</small></div></div><div className="float-card float-ai"><BrainCircuit size={20}/><div><b>AI &amp; ML</b><small>Academic focus</small></div></div>
          <div className="hero-orb"><Code2 size={31}/></div>
        </div>
        <a className="scroll-note" href="#about"><span/> SCROLL TO EXPLORE</a>
      </section>

      <section className="section-wrap about-section" id="about">
        <div className="section-heading"><p className="eyebrow">01 / ABOUT ME</p><h2>Curious mind.<br/><span>Practical builder.</span></h2></div>
        <div className="about-content"><p className="lead">I’m currently pursuing a B.Tech in Computer Science and Engineering with a specialization in Artificial Intelligence and Machine Learning at DNR College of Engineering and Technology.</p><p>I’m eager to learn, take on new challenges, and contribute to a team through communication, collaboration, and consistent effort. My goal is to grow into a developer who creates useful, reliable technology.</p><div className="about-stats"><div><strong>2023–27</strong><span>B.Tech journey</span></div><div><strong>SIH 2025</strong><span>Internal team lead</span></div><div><strong>82%</strong><span>NPTEL Java score</span></div></div></div>
      </section>

      <section className="section-wrap skills-section" id="skills">
        <div className="section-heading"><p className="eyebrow">02 / TOOLKIT</p><h2>Skills I’m growing<span>.</span></h2><p className="section-sub">A practical foundation, with plenty more to learn.</p></div>
        <div className="skills-grid">{skills.map((s) => <article className="skill-card" key={s.name}><div className="skill-icon">{s.icon}</div><div><h3>{s.name}</h3><p>{s.level}</p></div><ArrowUpRight className="skill-arrow" size={17}/></article>)}</div>
      </section>

      <section className="section-wrap projects-section" id="projects">
        <div className="section-heading project-heading"><div><p className="eyebrow">03 / SELECTED WORK</p><h2>Projects with a purpose<span>.</span></h2></div><span className="project-count">01 FEATURED PROJECT</span></div>
        <article className="project-card"><div className="project-visual"><div className="app-mock"><div className="mock-sidebar"><span className="mock-logo">E</span><i/><i/><i/><i/></div><div className="mock-main"><div className="mock-header"><span>EduManage</span><span className="mock-avatar">VS</span></div><p className="mock-welcome">Good morning 👋</p><small>Here's your campus overview</small><div className="mock-metrics"><div><small>Attendance</small><b>92%</b><span className="mock-bar"><i style={{width:'92%'}}/></span></div><div><small>Activities</small><b>08</b><span className="mock-bar"><i style={{width:'66%'}}/></span></div></div><div className="mock-schedule"><b>Today's schedule</b><div><span className="mock-time">09:00</span><span>Machine Learning <small>Room 204</small></span></div><div><span className="mock-time">11:00</span><span>Web Technologies <small>Room 106</small></span></div></div></div></div><div className="visual-tag">EDUCATION TECHNOLOGY</div></div><div className="project-info"><div className="project-topline"><span className="project-type">ACADEMIC PROJECT</span><span className="project-number">01 / 01</span></div><h3>Smart Curriculum Activity &amp; Attendance App</h3><p className="project-alias">Also known as EduManage</p><p>A student-focused concept for bringing curriculum activity and attendance workflows into one place, helping students and teachers keep track of classes, activities, and records.</p><ul><li>QR-based attendance check-in concept</li><li>Curriculum, class schedule, and activity management</li><li>Admin dashboard with attendance logs and reports</li><li>Login flow and organized student records</li></ul><div className="tag-list"><span>Education Tech</span><span>Attendance</span><span>Dashboard</span><span>App Concept</span></div></div></article>
      </section>

      <section className="section-wrap education-section" id="education">
        <div className="section-heading"><p className="eyebrow">04 / EDUCATION</p><h2>The learning path<span>.</span></h2></div>
        <div className="timeline"><article className="timeline-item"><div className="timeline-icon"><GraduationCap size={20}/></div><div className="timeline-body"><div className="timeline-meta"><span>2023 – 2027</span><span className="status-pill">IN PROGRESS</span></div><h3>B.Tech, Computer Science &amp; Engineering</h3><p className="timeline-focus">Specialization: Artificial Intelligence &amp; Machine Learning</p><p>DNR College of Engineering and Technology · Andhra Pradesh (JNTUK)</p><div className="education-score"><span>CGPA</span><strong>8.17 / 10</strong></div></div></article><article className="timeline-item"><div className="timeline-icon"><GraduationCap size={20}/></div><div className="timeline-body"><div className="timeline-meta"><span>Intermediate</span></div><h3>Intermediate – MBIPC</h3><p>Sri Vidyaniketan PU College, Karnataka</p><div className="education-score"><span>Percentage</span><strong>73.2%</strong></div></div></article><article className="timeline-item"><div className="timeline-icon"><GraduationCap size={20}/></div><div className="timeline-body"><div className="timeline-meta"><span>Secondary education</span></div><h3>SSC (General)</h3><p>Bright Way English Medium School, Karnataka</p><div className="education-score"><span>Percentage</span><strong>80.83%</strong></div></div></article></div>
      </section>

      <section className="section-wrap achievements-section" id="achievements"><div className="section-heading"><p className="eyebrow">05 / MILESTONES</p><h2>Proof of progress<span>.</span></h2></div><div className="achievement-grid"><article className="achievement-card"><div className="achievement-icon"><Trophy size={22}/></div><div><span className="achievement-label">HACKATHON</span><h3>Smart India Hackathon 2025</h3><p>Selected as internal hackathon team leader, contributing to a collaborative problem-solving experience.</p></div><span className="achievement-year">2025</span></article><article className="achievement-card"><div className="achievement-icon java-icon">J</div><div><span className="achievement-label">CERTIFICATION</span><h3>NPTEL – Java</h3><p>Completed Java certification with a reported score of 82%.</p></div><span className="achievement-year">82%</span></article></div></section>

      <section className="contact-section" id="contact"><div className="section-wrap contact-inner"><p className="eyebrow">06 / GET IN TOUCH</p><h2>Let’s build something<br/><span>meaningful.</span></h2><p>I’m open to internship opportunities and learning-focused collaborations.</p><div className="contact-links"><a href="https://www.linkedin.com/in/PADAMSETTIVEERANNASWAMY36" target="_blank" rel="noreferrer"><Linkedin size={18}/> LinkedIn <ArrowUpRight size={15}/></a><a href="https://github.com/swamyveeranna" target="_blank" rel="noreferrer"><Github size={18}/> GitHub <ArrowUpRight size={15}/></a><a href="mailto:veerannaswamy@example.com"><Mail size={18}/> Email <ArrowUpRight size={15}/></a></div><p className="email-note">Replace the placeholder email address in <code>src/main.jsx</code> with your active email before publishing.</p></div></section>
    </main>
    <footer className="footer"><a className="brand" href="#home"><span className="brand-mark">VS</span><span>Veeranna<span className="brand-dot">.</span></span></a><p>Designed with curiosity and built to keep improving.</p><span>© 2026 P. Veeranna Swamy</span></footer>
  </div>
}

createRoot(document.getElementById('root')).render(<App />);
