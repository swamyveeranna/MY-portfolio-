# P. Veeranna Swamy — Portfolio

A responsive, single-page React + Vite portfolio based on the resume details provided.

## Run locally

1. Install Node.js (LTS): https://nodejs.org/
2. Extract this folder and open it in VS Code.
3. Open the terminal in this folder and run:

   ```bash
   npm install
   npm run dev
   ```
4. Open the local URL shown in the terminal (usually `http://localhost:5173`).

## Before publishing

- In `src/main.jsx`, replace every `veerannaswamy@example.com` with your real email address.
- Verify education scores and all resume details are current.
- The featured project is presented as a project concept/summary. Add a live demo or repository link only when one exists.

## Build for deployment

```bash
npm run build
```

The production site is generated in the `dist` folder. It can be deployed to Vercel or Netlify.
